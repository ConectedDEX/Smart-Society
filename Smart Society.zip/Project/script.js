fetch('backend.php?action=getListings')
    .then(response => response.json())
    .then(data => {
        // Populate listings dynamically
    });
