<?php

// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartsociety";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for "Report an Issue"
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reportIssue') {
    $plotNo = $_POST['plotNo'];
    $issue = $_POST['issue'];
    $category = $_POST['category'];
    $phoneNumber = $_POST['phoneNumber'];

    // Prepare and bind statement
    $stmt = $conn->prepare("INSERT INTO issues (plot_no, issue, category, phone_number) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $plotNo, $issue, $category, $phoneNumber);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Issue reported successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to report issue."]);
    }

    $stmt->close();
    exit;
}

// Handle data retrieval for "View Listings"
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'getListings') {
    $query = "SELECT room_no, type, rent, for_rent FROM listings";
    $result = $conn->query($query);

    $listings = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $listings[] = $row;
        }
    }

    echo json_encode($listings);
    exit;
}

$conn->close();

?>
