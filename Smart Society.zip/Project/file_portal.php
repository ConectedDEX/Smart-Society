<?php
// Directory to store uploaded files
$uploadDir = 'uploads/';

// Ensure the directory exists
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['fileToUpload'])) {
    $fileName = basename($_FILES['fileToUpload']['name']);
    $targetFile = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $targetFile)) {
        echo "File uploaded successfully: <a href=\"$targetFile\">$fileName</a><br>";
    } else {
        echo "Error uploading file.<br>";
    }
}

// Get list of files for download
$files = array_diff(scandir($uploadDir), array('.', '..'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload and Download Portal</title>
</head>
<body>
    <h1>File Upload and Download Portal</h1>

    <!-- File Upload Form -->
    <h2>Upload File</h2>
    <form action="file_portal.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="fileToUpload" required>
        <button type="submit">Upload</button>
    </form>

    <!-- File Download Section -->
    <h2>Download Files</h2>
    <?php if (!empty($files)): ?>
        <ul>
            <?php foreach ($files as $file): ?>
                <li><a href="<?= htmlspecialchars($uploadDir . $file) ?>" download><?= htmlspecialchars($file) ?></a></li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No files available for download.</p>
    <?php endif; ?>
</body>
</html>
