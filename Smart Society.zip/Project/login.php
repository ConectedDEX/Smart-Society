<?php
// Database connection configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartsociety";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputUsername = $_POST['username'];
    $inputPassword = $_POST['password'];

    // Query to validate user credentials
    $stmt = $conn->prepare("SELECT role FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $inputUsername, $inputPassword);
    $stmt->execute();
    $stmt->bind_result($role);
    $stmt->fetch();

    if ($role) {
        if ($role === 'user') {
            header("Location: user/home.html");
        } elseif ($role === 'admin') {
            header("Location: admin/home(admin).html");
        }
        exit();
    } else {
        header("Location: login.html?error=1");
        exit();
    }

    $stmt->close();
}

$conn->close();
?>
